
BCCD - v1 resize-416x416
==============================

This dataset was exported via roboflow.ai on March 13, 2020 at 9:21 AM GMT

It includes 364 images.
Cells are annotated with bounding boxes in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


